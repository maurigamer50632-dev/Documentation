# MauNux 2.0 LTS

Una distribución Linux simulada en terminal, basada en **Ubuntu 24.04 LTS "Noble Numbat"**.

## Descripción

MauNux es un sistema operativo simulado que se ejecuta en la terminal, diseñado como una distribución derivada de Ubuntu. Incluye una shell completa con comandos Ubuntu reales simulados, gestor de paquetes apt/snap, systemd, neofetch con logo Ubuntu, y más.

## Archivos principales

- `main.c` — Punto de entrada: instalación, login, shell principal, GUI simulada, Firefox simulado
- `linux.c` — Subsistema Ubuntu completo con todos los comandos
- `Makefile` — Compilación con clang
- `config.bin` — Configuración del usuario (generada al instalar)

## Compilación

```bash
make        # Compila el proyecto
make clean  # Limpia binarios
```

## Características

- **Instalador** con selección de edición (Desktop, Shell, Server)
- **Login** estilo terminal Ubuntu
- **Shell principal** con prompt estilo Ubuntu (`usuario@maunux:~$`)
- **neofetch** con logo Ubuntu y datos reales del sistema
- **apt** completo: install, remove, update, upgrade, list
- **snap**: list, install, remove
- **systemctl**: start, stop, restart, enable, status
- **Comandos de red**: ip addr, ping, curl, ss -tulnp
- **Archivos**: ls -la, cd, mkdir, rm, cp, mv, cat, touch, echo
- **Sistema**: df -h, free -h, uptime, ps aux, top/htop, uname -a
- **Lenguajes**: java, python3, node, git (requieren instalación via apt)
- **GUI simulada** basada en GNOME 46
- **Firefox simulado** con User-Agent Ubuntu

## Base técnica

- **Kernel**: Linux 6.8.0-49-maunux (Ubuntu 6.8.0-49.49~24.04.1)
- **Base**: Ubuntu 24.04 LTS Noble Numbat
- **Init**: systemd 255
- **DE**: GNOME 46
- **Shell**: bash 5.2.21
