{ pkgs }: {
	deps = [
   pkgs.zulu11
   pkgs.mkinitcpio-nfs-utils
		pkgs.clang
		pkgs.ccls
		pkgs.gdb
		pkgs.gnumake
	];
}