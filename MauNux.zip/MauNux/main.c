#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

/**
 * MauNux v2.0 LTS - Basado en Ubuntu 24.04 LTS "Noble Numbat"
 * Distribucion derivada de Ubuntu para hardware moderno.
 * Kernel: Linux 6.8.0-maunux (Ubuntu 6.8.0-49.49)
 */

typedef enum {
    VERSION_NONE,
    VERSION_SHELL,
    VERSION_DESKTOP,
    VERSION_SERVER
} OSVersion;

typedef struct {
    char username[50];
    char password[50];
    OSVersion version;
    bool is_setup;
} SystemConfig;

SystemConfig config = {"", "", VERSION_NONE, false};

void clear_screen() {
    printf("\033[H\033[2J\033[3J");
    fflush(stdout);
}

void save_config() {
    FILE *f = fopen("config.bin", "wb");
    if (f) {
        fwrite(&config, sizeof(SystemConfig), 1, f);
        fclose(f);
    }
}

void load_config() {
    FILE *f = fopen("config.bin", "rb");
    if (f) {
        if (fread(&config, sizeof(SystemConfig), 1, f) != 1) {
            config.is_setup = false;
        }
        fclose(f);
    } else {
        config.is_setup = false;
    }
}

void print_ubuntu_logo() {
    printf("\033[1;31m          .-/+oossssoo+/-.\033[0m\r\n");
    printf("\033[1;31m      `:+ssssssssssssssssss+:`\033[0m\r\n");
    printf("\033[1;31m    -+ssssssssssssssssssyyssss+-\033[0m\r\n");
    printf("\033[1;31m  .ossssssssssssssssss\033[0m\033[1;37mdMMMNy\033[0m\033[1;31msssso.\033[0m\r\n");
    printf("\033[1;31m /sssssssssss\033[0m\033[1;37mhdmmNNmmyNMMMMh\033[0m\033[1;31mssssss/\033[0m\r\n");
    printf("\033[1;31m +sssssssss\033[0m\033[1;37mhm\033[0m\033[1;31myd\033[0m\033[1;37mMMMMMMMNddddmmyssssssss+\033[0m\r\n");
    printf("\033[1;31m /ssssssss\033[0m\033[1;37mhNMMM\033[0m\033[1;31myh\033[0m\033[1;37mhyyyyhmNMMMNhssssssss/\033[0m\r\n");
    printf("\033[1;31m .ssssssss\033[0m\033[1;37mdMMMNh\033[0m\033[1;31mssssssssss\033[0m\033[1;37mhNMMMd\033[0m\033[1;31mssssssss.\033[0m\r\n");
    printf("\033[1;31m +ssss\033[0m\033[1;37mhhhyNMMNy\033[0m\033[1;31mssssssssssss\033[0m\033[1;37myNMMMy\033[0m\033[1;31msssssss+\033[0m\r\n");
    printf("\033[1;31m oss\033[0m\033[1;37myNMMMNyMMh\033[0m\033[1;31mssssssssssssss\033[0m\033[1;37mhmmmh\033[0m\033[1;31mssssssso\033[0m\r\n");
    printf("\033[1;31m oss\033[0m\033[1;37myNMMMNyMMh\033[0m\033[1;31msssssssssssssshmmmh\033[0m\033[1;31mssssssso\033[0m\r\n");
    printf("\033[1;31m +ssss\033[0m\033[1;37mhhhyNMMNy\033[0m\033[1;31mssssssssssss\033[0m\033[1;37myNMMMy\033[0m\033[1;31msssssss+\033[0m\r\n");
    printf("\033[1;31m .ssssssss\033[0m\033[1;37mdMMMNh\033[0m\033[1;31mssssssssss\033[0m\033[1;37mhNMMMd\033[0m\033[1;31mssssssss.\033[0m\r\n");
    printf("\033[1;31m /ssssssss\033[0m\033[1;37mhNMMM\033[0m\033[1;31myh\033[0m\033[1;37mhyyyyhmNMMMNh\033[0m\033[1;31mssssssss/\033[0m\r\n");
    printf("\033[1;31m +sssssssss\033[0m\033[1;37mhm\033[0m\033[1;31myd\033[0m\033[1;37mMMMMMMMNdddd\033[0m\033[1;31mmyssssssss+\033[0m\r\n");
    printf("\033[1;31m /sssssssssss\033[0m\033[1;37mhdmmNNmmyNMMMMh\033[0m\033[1;31mssssss/\033[0m\r\n");
    printf("\033[1;31m .ossssssssssssssssss\033[0m\033[1;37mdMMMNy\033[0m\033[1;31msssso.\033[0m\r\n");
    printf("\033[1;31m   -+ssssssssssssssssssyyssss+-\033[0m\r\n");
    printf("\033[1;31m     `:+ssssssssssssssssss+:`\033[0m\r\n");
    printf("\033[1;31m         .-/+oossssoo+/-.\033[0m\r\n");
}

void setup_system() {
    char input[100];
    clear_screen();

    print_ubuntu_logo();

    printf("\r\n\033[1;37m╔══════════════════════════════════════════════╗\033[0m\r\n");
    printf("\033[1;37m║   Bienvenido a MauNux 2.0 LTS Installer      ║\033[0m\r\n");
    printf("\033[1;37m║   Basado en Ubuntu 24.04 LTS \"Noble Numbat\"   ║\033[0m\r\n");
    printf("\033[1;37m╚══════════════════════════════════════════════╝\033[0m\r\n\r\n");

    printf("\033[1;37mSelecciona la edicion de MauNux:\033[0m\r\n");
    printf("  \033[1;33m1\033[0m) MauNux Desktop  - Entorno grafico completo (GNOME)\r\n");
    printf("  \033[1;34m2\033[0m) MauNux Shell    - Solo terminal (minimalista)\r\n");
    printf("  \033[1;32m3\033[0m) MauNux Server   - Para servidores y VPS\r\n");
    printf("\r\nEdicion (1-3): ");
    fflush(stdout);

    if (fgets(input, sizeof(input), stdin)) {
        int choice = atoi(input);
        switch(choice) {
            case 1: config.version = VERSION_DESKTOP; break;
            case 2: config.version = VERSION_SHELL; break;
            case 3: config.version = VERSION_SERVER; break;
            default: config.version = VERSION_DESKTOP; break;
        }
    }

    printf("\r\n\033[1;37mNombre de usuario: \033[0m");
    fflush(stdout);
    if (fgets(config.username, sizeof(config.username), stdin)) {
        config.username[strcspn(config.username, "\n")] = 0;
        config.username[strcspn(config.username, "\r")] = 0;
    }

    printf("\033[1;37mContrasena: \033[0m");
    fflush(stdout);
    if (fgets(config.password, sizeof(config.password), stdin)) {
        config.password[strcspn(config.password, "\n")] = 0;
        config.password[strcspn(config.password, "\r")] = 0;
    }

    config.is_setup = true;
    save_config();

    printf("\r\n\033[1;32m[  OK  ] Instalacion completada.\033[0m\r\n");
    printf("\033[1;32m[  OK  ] Usuario '%s' creado.\033[0m\r\n", config.username);
    printf("\033[1;32m[  OK  ] Repositorios de Ubuntu configurados.\033[0m\r\n");
    printf("\033[1;32m[  OK  ] MauNux 2.0 LTS listo para usar.\033[0m\r\n");
    printf("\r\nPresiona ENTER para iniciar MauNux.\r\n");
    fflush(stdout);

    char dummy[10];
    if (fgets(dummy, sizeof(dummy), stdin)) {}
}

bool login() {
    clear_screen();
    printf("\r\n\033[1;31m  MauNux 2.0 LTS\033[0m  \033[0;90m(Based on Ubuntu 24.04 Noble Numbat)\033[0m\r\n");
    printf("\033[0;90m  Kernel 6.8.0-maunux | x86_64\033[0m\r\n\r\n");
    printf("\033[1;32mIniciando sesion como %s...\033[0m\r\n", config.username);
    fflush(stdout);
    return true;
}

void pc_settings() {
    char input[100];
    while (true) {
        clear_screen();
        printf("\r\n\033[1;37m Configuracion del sistema - MauNux 2.0 LTS\033[0m\r\n");
        printf("\033[0;90m─────────────────────────────────────────\033[0m\r\n");
        printf("1. Sistema         -> Informacion del sistema\r\n");
        printf("2. Aplicaciones    -> Gestionar paquetes (apt/snap)\r\n");
        printf("3. Hardware        -> CPU, RAM y almacenamiento\r\n");
        printf("4. Red             -> Configuracion de red\r\n");
        printf("5. Actualizaciones -> Buscar actualizaciones de Ubuntu\r\n");
        printf("6. Salir           -> Volver al terminal\r\n");
        printf("\r\nSeleccion (1-6): ");
        fflush(stdout);

        if (fgets(input, sizeof(input), stdin) == NULL) break;
        int choice = atoi(input);

        if (choice == 1) {
            printf("\r\n\033[1;37m Sistema:\033[0m\r\n");
            printf("  OS:            MauNux 2.0 LTS (Ubuntu 24.04 Noble Numbat)\r\n");
            printf("  Kernel:        Linux 6.8.0-49-maunux\r\n");
            printf("  Arquitectura:  x86_64\r\n");
            printf("  Soporte hasta: Abril 2029\r\n");
            printf("  Init:          systemd 255\r\n");
        } else if (choice == 2) {
            printf("\r\n\033[1;37m Gestores de paquetes disponibles:\033[0m\r\n");
            printf("  apt    - Paquetes del repositorio Ubuntu\r\n");
            printf("  snap   - Aplicaciones snap (Canonical)\r\n");
            printf("  flatpak - Aplicaciones Flatpak\r\n");
        } else if (choice == 3) {
            printf("\r\n\033[1;37m Hardware detectado:\033[0m\r\n");
            printf("  CPU: 8 nucleos @ 3.6 GHz (Multi-core)\r\n");
            printf("  RAM: 16 GB DDR5\r\n");
            printf("  GPU: Compatible con drivers Ubuntu\r\n");
            printf("  Disco: 512 GB NVMe SSD\r\n");
        } else if (choice == 4) {
            printf("\r\n\033[1;37m Red:\033[0m\r\n");
            printf("  Interfaz: eth0 / wlan0\r\n");
            printf("  DNS: 8.8.8.8 / 1.1.1.1\r\n");
            printf("  Repositorios: archive.ubuntu.com\r\n");
        } else if (choice == 5) {
            printf("\r\n\033[1;32m Comprobando actualizaciones de Ubuntu...\033[0m\r\n");
            printf("  Leyendo lista de paquetes...\r\n");
            printf("  Calculando arbol de dependencias...\r\n");
            printf("  0 paquetes actualizados, 0 recien instalados.\r\n");
            printf("  \033[1;32mEl sistema esta al dia.\033[0m\r\n");
        } else if (choice == 6) {
            break;
        }
        if (choice >= 1 && choice <= 5) {
            printf("\r\nPresiona ENTER para continuar.\r\n");
            fflush(stdout);
            char wait[10];
            if (fgets(wait, sizeof(wait), stdin)) {}
        }
    }
}

extern void run_ubuntu_subsystem(const char *username);

void run_browser(const char *url) {
    clear_screen();
    printf("\033[1;37m┌──────────────────────────────────────────────────────────────────────────────┐\033[0m\r\n");
    printf("\033[1;37m│ \033[1;31m(X)\033[0m \033[1;33m(_)\033[0m \033[1;32m( )\033[0m  \033[1;31m🦊\033[0m \033[1;37mFirefox - Navegador de Ubuntu                       < >  ↻  ⌂ \033[0m │\r\n");
    printf("\033[1;37m├──────────────────────────────────────────────────────────────────────────────┤\033[0m\r\n");
    printf("\033[1;37m│ \033[1;32m🔒\033[0m \033[1;34mhttps://%s\033[0m \033[1;37m                                       [⭐] [⋮] │\033[0m\r\n", url);
    printf("\033[1;37m└──────────────────────────────────────────────────────────────────────────────┘\033[0m\r\n");
    printf("\033[0;90m  User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0\033[0m\r\n\r\n");

    if (strcmp(url, "ubuntu.com") == 0) {
        printf("  \033[1;31m Ubuntu\033[0m - The leading open source platform\r\n\r\n");
        printf("  Ubuntu is the world's favourite Linux for cloud, IoT and desktops.\r\n");
        printf("  Download Ubuntu 24.04 LTS >> \r\n");
    } else if (strcmp(url, "google.com") == 0) {
        printf("          \033[1;31mG\033[1;32mo\033[1;33mo\033[1;34mg\033[1;32ml\033[1;31me\033[0m\r\n\r\n");
        printf("    [____________________________________________________] [ Buscar ]\r\n\r\n");
        printf("    \033[1;32m✔ Proteccion de rastreadores activa (Firefox en Ubuntu)\033[0m\r\n");
    } else if (strcmp(url, "packages.ubuntu.com") == 0) {
        printf("  \033[1;31m Ubuntu Packages\033[0m\r\n\r\n");
        printf("  Ubuntu Noble Numbat (24.04)\r\n");
        printf("  Busca paquetes en los repositorios oficiales de Ubuntu.\r\n");
    } else {
        printf("    \033[1;36mCargando %s...\033[0m\r\n", url);
        printf("    [████████████████████████████████] 100%%\r\n\r\n");
        printf("    Contenido de %s cargado.\r\n", url);
    }

    printf("\r\n\033[0;90m────────────────────────────────────────────────────────────────────────────────\033[0m\r\n");
    printf(" Presiona ENTER para cerrar Firefox.\r\n");
    fflush(stdout);
    char wait[10];
    if (fgets(wait, sizeof(wait), stdin)) {}
}

void run_gui() {
    clear_screen();
    printf("\033[1;35m════════════════════════════════════════════════════════════════════════════════\033[0m\r\n");
    printf("\033[1;37m  MauNux Desktop 2.0 - GNOME 46 (Ubuntu 24.04)                                  \033[0m\r\n");
    printf("\033[1;35m════════════════════════════════════════════════════════════════════════════════\033[0m\r\n\r\n");
    printf("    \033[1;34m┌────────────────────────────────────────────────────────┐\033[0m\r\n");
    printf("    \033[1;34m│\033[0m  \033[1;31m●\033[0m \033[1;33m●\033[0m \033[1;32m●\033[0m   \033[1;37mMauNux Desktop\033[0m                        \033[1;34m│\033[0m\r\n");
    printf("    \033[1;34m├────────────────────────────────────────────────────────┤\033[0m\r\n");
    printf("    \033[1;34m│\033[0m                                                    \033[1;34m│\033[0m\r\n");
    printf("    \033[1;34m│\033[0m   \033[1;31m[Files]\033[0m  \033[1;32m[Terminal]\033[0m  \033[1;34m[Firefox]\033[0m  \033[1;33m[Settings]\033[0m   \033[1;34m│\033[0m\r\n");
    printf("    \033[1;34m│\033[0m                                                    \033[1;34m│\033[0m\r\n");
    printf("    \033[1;34m│\033[0m   Basado en GNOME 46 + Ubuntu 24.04 Noble Numbat   \033[1;34m│\033[0m\r\n");
    printf("    \033[1;34m│\033[0m                                                    \033[1;34m│\033[0m\r\n");
    printf("    \033[1;34m└────────────────────────────────────────────────────────┘\033[0m\r\n\r\n");
    printf("    \033[0;90m(Simulacion de interfaz grafica GNOME)\033[0m\r\n");
    printf("\r\nPresiona ENTER para volver al terminal.\r\n");
    fflush(stdout);
    char wait[10];
    if (fgets(wait, sizeof(wait), stdin)) {}
}

int main() {
    load_config();
    if (!config.is_setup) setup_system();
    login();
    run_ubuntu_subsystem(config.username);
    return 0;
}
