import os
import telebot

TOKEN = os.environ.get("TELEGRAM_TOKEN")
if not TOKEN:
    raise ValueError("No se encontro TELEGRAM_TOKEN en las variables de entorno.")

bot = telebot.TeleBot(TOKEN)

MAUNUX_INFO = """
🐧 *MauNux 2.0 LTS*
━━━━━━━━━━━━━━━━━━━━
🖥️ *OS:* MauNux 2.0 LTS x86\\_64
📦 *Base:* Ubuntu 24.04 Noble Numbat
🔧 *Kernel:* Linux 6.8.0\\-49\\-maunux
🖱️ *DE:* GNOME 46
🐚 *Shell:* bash 5.2.21
💾 *Memory:* 3421MiB / 16384MiB
💿 *Disk:* 42G / 512G \\(8%\\)
"""

NEOFETCH = """
```
        .-/+oossssoo+/-.        maupop3@maunux
    `:+ssssssssssssssssss+:`    ---------------
  -+ssssssssssssssssssyyssss+-  OS: MauNux 2.0 LTS
 .ossssssssssssssssss dMMMNy .  Base: Ubuntu 24.04
 /ssssssssssss hdmmNNmmyNMMMMh  Kernel: 6.8.0-maunux
 +ssssssssss hm yd MMMMMMMNdddd Shell: bash 5.2.21
 /ssssssssss hNMMMyh hyyyyh mNM DE: GNOME 46
 .ssssssssss dMMMNh ssssssss hN CPU: 8 cores @ 3.6GHz
 +ssss hhhyNMMNy ssssssss yNMMM Memory: 3421/16384MiB
 oss yNMMMNyMMh ssssssss hmmmh  Disk: 42G / 512G
```
"""

@bot.message_handler(commands=['start'])
def start(message):
    nombre = message.from_user.first_name
    bot.reply_to(message,
        f"¡Hola, {nombre}\\! 👋\n\n"
        "Soy el bot oficial de *MauNux 2\\.0 LTS* 🐧\n"
        "Una distribución basada en Ubuntu 24\\.04\n\n"
        "Usa /help para ver los comandos disponibles\\.",
        parse_mode="MarkdownV2"
    )

@bot.message_handler(commands=['help'])
def help_cmd(message):
    bot.reply_to(message,
        "📋 *Comandos de MauNux Bot*\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "/start \\- Mensaje de bienvenida\n"
        "/info \\- Información del sistema MauNux\n"
        "/neofetch \\- Ver neofetch de MauNux\n"
        "/version \\- Versión de MauNux\n"
        "/apt \\- Info del gestor de paquetes\n"
        "/kernel \\- Info del kernel\n"
        "/about \\- Sobre MauNux\n"
        "/help \\- Esta ayuda",
        parse_mode="MarkdownV2"
    )

@bot.message_handler(commands=['info'])
def info(message):
    bot.reply_to(message, MAUNUX_INFO, parse_mode="MarkdownV2")

@bot.message_handler(commands=['neofetch'])
def neofetch(message):
    bot.reply_to(message, NEOFETCH, parse_mode="MarkdownV2")

@bot.message_handler(commands=['version'])
def version(message):
    bot.reply_to(message,
        "🐧 *MauNux 2\\.0 LTS*\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📌 Versión: `2.0 LTS`\n"
        "📦 Base: Ubuntu 24\\.04 Noble Numbat\n"
        "📅 Soporte hasta: Abril 2029\n"
        "🔧 Kernel: `6.8.0-49-maunux`\n"
        "⚙️ Init: systemd 255",
        parse_mode="MarkdownV2"
    )

@bot.message_handler(commands=['apt'])
def apt(message):
    bot.reply_to(message,
        "📦 *APT \\- Gestor de paquetes de MauNux*\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🔗 Repositorios: `archive.ubuntu.com/ubuntu`\n"
        "🗂️ Versión apt: `2.7.14`\n\n"
        "*Comandos principales:*\n"
        "`apt update` \\- Actualizar listas\n"
        "`apt install [pkg]` \\- Instalar paquete\n"
        "`apt remove [pkg]` \\- Eliminar paquete\n"
        "`apt upgrade` \\- Actualizar sistema",
        parse_mode="MarkdownV2"
    )

@bot.message_handler(commands=['kernel'])
def kernel(message):
    bot.reply_to(message,
        "⚙️ *Kernel de MauNux*\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🔧 Versión: `Linux 6.8.0-49-maunux`\n"
        "🏗️ Arquitectura: `x86_64`\n"
        "📋 Tipo: `SMP PREEMPT_DYNAMIC`\n"
        "🐧 Base Ubuntu: `6.8.0-49.49~24.04.1`\n"
        "📅 Compilado: Oct 7 2025",
        parse_mode="MarkdownV2"
    )

@bot.message_handler(commands=['about'])
def about(message):
    bot.reply_to(message,
        "🐧 *Sobre MauNux*\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "MauNux es una distribución Linux basada en *Ubuntu 24\\.04 LTS* \\\"Noble Numbat\\\"\\.\n\n"
        "👤 Usuario: `maupop3@maunux`\n"
        "🌐 Web: maunux\\.os\n"
        "📦 Paquetes: apt \\+ snap \\+ flatpak\n"
        "🖥️ Escritorio: GNOME 46 \\+ Mutter\n\n"
        "Desarrollado con ❤️ sobre Ubuntu\\.",
        parse_mode="MarkdownV2"
    )

@bot.message_handler(func=lambda m: True)
def echo(message):
    text = message.text.lower()
    if "maunux" in text:
        bot.reply_to(message, "🐧 ¡Sí, soy el bot de MauNux\\! Usa /info para ver la info del sistema\\.", parse_mode="MarkdownV2")
    elif "ubuntu" in text:
        bot.reply_to(message, "📦 MauNux está basado en *Ubuntu 24\\.04 LTS Noble Numbat* 🐧", parse_mode="MarkdownV2")
    elif "hola" in text or "hello" in text or "hi" in text:
        bot.reply_to(message, f"¡Hola\\! Usa /help para ver los comandos disponibles 😊", parse_mode="MarkdownV2")
    else:
        bot.reply_to(message, "No entiendo ese comando\\. Usa /help para ver los disponibles\\.", parse_mode="MarkdownV2")

print("🐧 MauNux Bot iniciado correctamente.")
print("Esperando mensajes de Telegram...")
bot.infinity_polling()
